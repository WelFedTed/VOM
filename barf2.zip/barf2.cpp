/* barf2.cpp - Better Archiver with Recursive Functionality, version 2.00.

(C) 2010, Matt Mahoney. Oct. 5.
This program is licensed under GPL v3, http://www.gnu.org/licenses/gpl.html

barf2 is a recursive data compressor for arbitrary or random data. It is
guaranteed that for any non-empty input that iterated compression contains
no cycles, and furthermore that no iteration increases the size of the data.
Because there are only a finite number of strings of any given size, the
size must eventually decrease by at least one byte. Thus, continued
iteration is guaranteed to compress any input file to a size of 0 bytes.
The data may be restored to its original value by decompressing for the
same number of cycles.

The compression and decompression algorithms are both O(log^2 N), where N
is the number of iterations.

barf2 allows you to specify the number N of compression or decompression
iterations on the command line and run it only once, rather than run it N
times. Or you have the option to leave N unspecified and barf2 will calculate
the exact number of iterations needed to compress to an empty file. It will
then compress the file and save N to the file barf2.count. When you decompress,
you can either give the program N from this file or you can leave it blank and
barf2 will read N from this file without you having to enter it.

Commands are as follows:

To compress N times:     barf2 cN input output
To decompress N times:   barf2 dN input output
To compress to 0 bytes:  barf2 c  input output (N saved to barf2.count)
To decompress:           barf2 d  input output (get N from barf2.count)

Command cN (for example, c100) compresses N times, or
until the output has size 0 bytes, whichever comes first. If the
input cannot be compressed N times, then the actual number of
iterations will be shown.

Command dN (for example, d100) will restore the original data.

Command c (omitting N) will compress until the output size is 0.
It will count the number of iterations required and save this number
to the file barf2.count. This number could then be passed to the
decompressor as N.

Command d (omitting N) will read N from the file barf2.count.

The compression algorithm is to treat the input file as a base 256
integer (with digit values 1..256, MSB first) and subtract 1. The
decompression algorithm is to add 1.

Note that barf2 is bijective. Any input is valid to the decompresser
and can be restored by compression for the same number of cycles.

This program is slow on big files. You might want to split the input
into chunks of about 10 KB and compress them separately.
*/

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <ctype.h>
#include <time.h>
#include <string>
using std::string;

// convert binary (base 256, digits 1..256, MSB first) to decimal string.
void b2d(string in, string& out) {
  out="";
  for (int i=0; i<int(in.size()); ++i) {  // for each digit of in
    int carry=(in[i]&255)+1;  // out = out*256 + digit
    for (int j=out.size()-1; j>=0; --j) {  // multiply in place
      int x=(out[j]-'0')*256+carry;
      out[j]=x%10+'0';
      carry=x/10;
    }
    while (carry>0) {  // append overflow digits
      out=char(carry%10+'0')+out;
      carry/=10;
    }
  }
}

// Convert decimal ('0'..'9') to binary, inverse of b2d().
void d2b(string in, string& out) {
  out="";
  for (int i=0; i<int(in.size()); ++i) {  // for each digit of in
    int carry=in[i]-'0';  // out = out*10 + digit
    for (int j=out.size()-1; j>=0; --j) {  // multiply in place
      int x=((out[j]&255)+1)*10+carry;
      out[j]=x-1&255;
      carry=x-1>>8;
    }
    while (carry>0) {  // append overflow digits
      out=char(carry-1&255)+out;
      carry=carry-1>>8;
    }
  }
}

// sum += s (base 256)
void add(string& sum, string s) {
  int carry=0;
  for (int i=int(sum.size())-1, j=int(s.size())-1;; --i, --j) {
    int di = i>=0?(sum[i]&255)+1:0;
    int dj = j>=0?(s[j]&255)+1:0;
    int x=di+dj+carry;
    if (x<1) break;
    carry=x-1>>8;
    x=x-1&255;
    if (i>=0) sum[i]=x;
    else sum=char(x)+sum;
  }
}

// sum -= s (base 256). If result < 0 then set sum = 0 and return false.
bool sub(string& sum, string s) {
  if (sum.size()<s.size()) return sum="", false;
  int carry=0;
  for (int i=int(sum.size())-1, j=int(s.size())-1; i>=0; --i, --j) {
    int di = (sum[i]&255)+1;
    int dj = j>=0?(s[j]&255)+1:0;
    int x=di-dj+carry;
    carry=x-1>>8;
    sum[i]=x-1&255;
  }
  while (carry && sum.size()) {  // trim leading zeros
    assert(carry<=0);
    int x=carry*256+(sum[0]&255)+1;
    if (x==0 || x==-1) carry=x, sum=sum.substr(1);
    else if (x>0) return true;
    else return sum="", false;
  }
  return carry==0;
}

int main(int argc, char** argv) {

  // Get command line args or print help message
  if (argc!=4 || argv[1][0]!='c' && argv[1][0]!='d') {
    printf(
      "BARF2 - Better Archiver with Recursive Functionality, v2.00\n"
      "(C) 2010, Matt Mahoney\n"
      "This is free software under GPL v3, http://www.gnu.org/licenses/gpl.html\n"
      "\n"
      "Usage: barf2 command input output\n"
      "Commands are:\n"
      "  cN - to compress N times (for example c100)\n"
      "  c  - to compress to 0 bytes and save N to file barf2.count\n"
      "  dN - to decompress N times\n"
      "  d  - to decompress and get N from barf2.count\n"
    );
    return 1;
  }

  // Get start time
  clock_t start=clock();

  // Open files
  FILE* in=fopen(argv[2], "rb");
  if (!in) perror(argv[2]), exit(1);
  FILE* out=fopen(argv[3], "wb");
  if (!out) perror(argv[3]), exit(1);
  const char* countfile="barf2.count";
  string indata, countdata, outdata;

  // Compress
  if (argv[1][0]=='c') {
    int c;
    while ((c=getc(in))!=EOF)
      indata+=char(c);

    // Compress as much as possible and save N to countfile
    if (!argv[1][1]) {  // no N
      printf("Compressing N times and saving N in %s...\n", countfile);
      b2d(indata, countdata);
      FILE* count=fopen(countfile, "wb");
      if (!count) perror(countfile), exit(1);
      fprintf(count, "%s", countdata.c_str());
      fclose(count);
    }

    // Try to compress N times by subtracting N from input
    else {
      printf("Compressing %s times...\n", argv[1]+1);
      d2b(argv[1]+1, countdata);  // N
      outdata=indata;
      if (sub(outdata, countdata)) {
        for (int i=0; i<int(outdata.size()); ++i)
          putc(outdata[i], out);
      }
      else {  // N > input
        b2d(indata, countdata);
        printf("Can only compress %s times\n", countdata.c_str());
      }
    }
  }

  // Decompress
  if (argv[1][0]=='d') {
    int c;
    while ((c=getc(in))!=EOF)
      indata+=char(c);

    // Get N from countfile
    if (!argv[1][1]) {  // no N
      printf("Reading number of times to decompress from %s...\n", countfile);
      FILE* count=fopen(countfile, "rb");
      if (!count) perror(countfile), exit(1);
      while ((c=getc(count))!=EOF)
        if (isdigit(c))
          countdata+=char(c);
      fclose(count);
    }

    // Get N from command line
    else {
      countdata=argv[1]+1;  // N
      printf("Decompressing %s times...\n", countdata.c_str());
    }

    // Decompress by adding N to input
    d2b(countdata, outdata);
    add(outdata, indata);
    for (int i=0; i<int(outdata.size()); ++i)
      putc(outdata[i], out);
  }

  // Report result
  printf("%s (%ld bytes) -> %s (%ld bytes) in %1.2f seconds\n",
    argv[2], ftell(in), argv[3], ftell(out),
    double(clock()-start)/CLOCKS_PER_SEC);
  fclose(out);
  fclose(in);
  return 0;
}
